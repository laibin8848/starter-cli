import index from './views/index.vue'

export default {
  MN: '@moduleName@',
  BR: '/module/@moduleName@',
  icon: 'el-icon-folder',
  store: {
    namespaced: true,
    state: {},
    mutations: {},
    actions: {},
    getters: {}
  },
  routes: [
    {
      path: '/module/@moduleName@',
      name: 'module-@moduleName@-index',
      meta: {
        hidden: false,
        title: '@moduleName@'
      },
      component: index,
      children: []
    }
  ]
}
