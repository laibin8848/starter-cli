<template>
  <div>
    我是一个新增的模块，空空如也！来改造我吧！
  </div>
</template>

<script>
  import { defineComponent } from 'vue'

  export default defineComponent({
    setup() {
    }
  })
</script>
<style lang="scss" scoped>

</style>
